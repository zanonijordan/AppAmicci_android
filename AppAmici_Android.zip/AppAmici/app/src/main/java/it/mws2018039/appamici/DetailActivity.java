package it.mws2018039.appamici;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import it.mws2018039.amici.dto.AmiciDTO;

public class DetailActivity extends AppCompatActivity {
    AmiciDTO dto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        this.dto = (AmiciDTO) getIntent().getSerializableExtra( RowAdapter.PAR_AMICO_DTO );
        setTextViewValue(R.id.detail_cognome,   dto.getCognome());
        setTextViewValue(R.id.detail_nome,      dto.getNome());
        setTextViewValue(R.id.detail_lat,       ""+dto.getLat());
        setTextViewValue(R.id.detail_lng,       ""+dto.getLng());
    }

    public void openOnMaps(View view) {
        Uri gmmIntentUri = Uri.parse("geo:"+ dto.getLat() +","+ dto.getLng() );
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        //mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }

    private void setTextViewValue( int id, String val ){
        TextView tv = findViewById(id);
        tv.setText(val);
    }
}
