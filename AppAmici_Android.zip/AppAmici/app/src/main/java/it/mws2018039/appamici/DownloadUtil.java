package it.mws2018039.appamici;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import it.mws2018039.amici.exception.AppAmiciException;

public class DownloadUtil {
    public static String downloadJson( String url) throws AppAmiciException {
        String str = null;
        try {
            URL aURL = new URL(url);
            URLConnection conn = aURL.openConnection();
            conn.connect();
            InputStream is = conn.getInputStream();
            str = readStream( is );
            is.close();
            return str;
        } catch (IOException e) {
            Log.e("Hub","Error getting the image from server : " + e.getMessage().toString());
            throw new AppAmiciException("ERRORE: Verificare connessione...\n"+e.getMessage());
        }
    }

    private static String readStream(InputStream in) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            String nextLine = "";
            while ((nextLine = reader.readLine()) != null) {
                sb.append( nextLine );
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}
