package it.mws2018039.appamici;

import android.app.ListActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;

import it.mws2018039.amici.dto.AmiciDTO;
import it.mws2018039.amici.encoder.AmiciJsonEncored;
import it.mws2018039.amici.exception.AppAmiciException;

public class MainActivity extends ListActivity {
    public static int MIO_ID = 1;
    public static final String SERVER_URL = "http://192.168.1.159:8080/AmiciMWS/AmiciService";
    public static final String SERVER_CMD_ELENCO_AMICI    = "GET_ELENCO_AMICI";
    public static final String SERVER_CMD_INVIA_POSIZIONE = "IMPOSTA_POSIZIONE";
    ArrayList<AmiciDTO> elenco;

    public Switch statoSW;
    public boolean aggiorna = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statoSW = findViewById(R.id.main_stato);
        statoSW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(aggiorna) new SetOnlineStatusTask().execute();
            }
        });
        //new DownloadAmiciTask().execute();
    }

    @Override
    protected void onResume() {
        super.onResume();
        new DownloadAmiciTask().execute();
    }

    public void inviaPosizione(View view) {
        Intent i = new Intent(this, PositionActivity.class);
        startActivity(i);
    }

    private class SetOnlineStatusTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            //String json = "[{\"id\":1,\"cognome\":\"Rizzo\",\"nome\":\"Emanuele\",\"nickname\":\"lele\",\"tel\":null,\"lat\":25.123123,\"lng\":22.321321,\"seOnline\":1},{\"id\":2,\"cognome\":\"Rizzo 2\",\"nome\":\"Emanuele 2\",\"nickname\":\"lele2\",\"tel\":null,\"lat\":25.123123,\"lng\":22.321321,\"seOnline\":1}]";
            String ok = null;
            try {
                int seOnline = 0;
                if( statoSW.isChecked() ) seOnline = 1;
                ok = DownloadUtil.downloadJson( MainActivity.SERVER_URL +"?CMD=SET_ONLINE&SE_ONLINE="+seOnline+"&IP_ID="+MIO_ID );
            } catch (AppAmiciException e) {
                e.printStackTrace();
                return e.getMessage();
            }
            return ok;
        }

        @Override
        protected void onPostExecute(String ok) {
            super.onPostExecute(ok);
            if( ok==null || !ok.equals("OK")){
                mostraToast("ERRORE: impossibile inviare stato");
                //rimetto lo switch come primq
                aggiorna = false;
                statoSW.setChecked( !statoSW.isChecked() );
            } else {
                //new DownloadAmiciTask().execute();
            }
            aggiorna = true;
        }
    }

    private class DownloadAmiciTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            //String json = "[{\"id\":1,\"cognome\":\"Rizzo\",\"nome\":\"Emanuele\",\"nickname\":\"lele\",\"tel\":null,\"lat\":25.123123,\"lng\":22.321321,\"seOnline\":1},{\"id\":2,\"cognome\":\"Rizzo 2\",\"nome\":\"Emanuele 2\",\"nickname\":\"lele2\",\"tel\":null,\"lat\":25.123123,\"lng\":22.321321,\"seOnline\":1}]";
            String json = null;
            try {
                json = DownloadUtil.downloadJson( MainActivity.SERVER_URL +"?CMD="+ MainActivity.SERVER_CMD_ELENCO_AMICI );
            } catch (AppAmiciException e) {
                e.printStackTrace();
                return e.getMessage();
            }
            return json;
        }

        @Override
        protected void onPostExecute(String json) {
           super.onPostExecute(json);
           if( json==null ){
               mostraToast("ERRORE: Nessun dato trovato");
               return;
           }
           if( json.startsWith("ERRORE:") ){
               mostraToast(json);
               return;
           }
           ArrayList<AmiciDTO> aList = null;
           try{
               // converto json in arraylist<dto>
               aList = AmiciJsonEncored.toAmiciDTOList( json );
           } catch (Exception e){
               e.printStackTrace();
               aList = new ArrayList<>();
           }
           searchAmici(aList);
       }
    }


    private void refreshList(){
        RowAdapter adapter = new RowAdapter(this, elenco);
        setListAdapter( adapter );
    }

    public void mostraToast( String txt ){
        Toast.makeText(this, txt, Toast.LENGTH_LONG).show();
    }

    public void search(View view) {
        new DownloadAmiciTask().execute();
    }

    public void searchAmici( ArrayList<AmiciDTO> aList ) {
        EditText s = findViewById(R.id.main_search);
        String searchStr = ""+s.getText();

        this.elenco = new ArrayList<>();
        for (AmiciDTO currA :aList) {
            if(        currA.getId()!=MIO_ID
                    && (currA.getCognome().toLowerCase().contains( searchStr ) || currA.getNome().toLowerCase().contains( searchStr.toLowerCase() ) ) )
                this.elenco.add( currA );
        }

        refreshList();
    }
}
