package it.mws2018039.appamici;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import java.sql.Timestamp;
import it.mws2018039.amici.exception.AppAmiciException;

public class PositionActivity extends AppCompatActivity {
    private static final int MY_ID = 1;
    Location mLocation;
    private LocationManager locationManager = null;
    private static final int MIN_DIST = 10;
    private static final int MIN_PERIOD = 10000;

    private LocationListener locationListener = new LocationListener() {

        @Override
        public void onLocationChanged(Location location) {
            updateGUI(location);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    private void updateGUI(Location location){
        Toast.makeText(this, "updating position...", Toast.LENGTH_SHORT).show();

        double latitude = location.getLatitude();
        updateText(R.id.position_lat, String.valueOf(latitude));

        double longitude = location.getLongitude();
        updateText(R.id.position_lng, String.valueOf(longitude));

        Timestamp ts = new Timestamp(location.getTime());
        updateText(R.id.position_time, ""+ ts);

        this.mLocation = location;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_position);
    }

    @Override
    protected void onResume() {
        super.onResume();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (location != null)
            updateGUI(location);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_PERIOD, MIN_DIST, locationListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (locationManager != null && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
           locationManager.removeUpdates(locationListener);
    }

    public void sendPosition(View view) {
        float accuracy = this.mLocation.getAccuracy();
        if( this.mLocation==null || accuracy>MIN_DIST){
            Toast.makeText(this, "precisione troppo bassa, attendere ("+ accuracy +" m)", Toast.LENGTH_LONG).show();
            return;
        }
        double lat;
        double lng;

        TextView latTV  = findViewById(R.id.position_lat);
        TextView lngTV  = findViewById(R.id.position_lng);
        TextView timeTV = findViewById(R.id.position_time);
        lat  = new Double(""+ latTV.getText());
        lng  = new Double(""+ lngTV.getText());

        showToast( "invio mia posizione:\n" +
                "Lat: "+ lat +"\n" +
                "Lng: "+ lng +"\n" +
                "Data: "+ timeTV.getText());
        Log.i("POSITION", "invio mia posizione: Lat: "+ lat +" - Lng: "+ lng);
        new SendPositionTask().execute(lat, lng);
    }

    private void showToast( String txt ){
        Toast.makeText(this, txt, Toast.LENGTH_LONG).show();
    }
    private void updateText(int id, String text) {
        TextView textView = findViewById(id);
        textView.setText(text);
    }

    public void testPosition(View view) {
        Double myLatitude  = mLocation.getLatitude();
        Double myLongitude = mLocation.getLongitude();
        String labelLocation = "Lele";
        //Uri gmmIntentUri = Uri.parse("geo:"+ mLocation.getLatitude() +","+ mLocation.getLongitude() );
        //Uri gmmIntentUri = Uri.parse("geo:<" + myLatitude  + ">,<" + myLongitude + ">?q=<" + myLatitude  + ">,<" + myLongitude + ">(" + labelLocation + ")" );
        String urlStr = "geo:" + myLatitude  +","+ myLongitude +"?q="+ myLatitude  +","+ myLongitude +"(" + labelLocation + ")";
        Log.i("POSITION", urlStr);
        Uri gmmIntentUri = Uri.parse( urlStr );
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        //mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }

    private class SendPositionTask extends AsyncTask<Double, Void, String> {

        @Override
        protected String doInBackground(Double... geo) {
            String json;
            try {
                json = DownloadUtil.downloadJson( MainActivity.SERVER_URL +
                        "?CMD="     + MainActivity.SERVER_CMD_INVIA_POSIZIONE +
                        "&IP_ID="   + MY_ID +
                        "&IP_LAT="  + geo[0]+
                        "&IP_LNG="  + geo[1]);
            } catch (AppAmiciException e) {
                e.printStackTrace();
                return e.getMessage();
            }
            return json;
        }

        @Override
        protected void onPostExecute(String json) {
            super.onPostExecute(json);
            if( json!=null && json.trim().toUpperCase().equals("OK") ){
                finish();
            } else {
                showToast("ERRORE");
            }

        }
    }
}
