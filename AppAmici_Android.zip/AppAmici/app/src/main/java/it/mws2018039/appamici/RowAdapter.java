package it.mws2018039.appamici;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import it.mws2018039.amici.dto.AmiciDTO;

public class RowAdapter extends ArrayAdapter<AmiciDTO> {
    public static final String PAR_AMICO_DTO = "AMICO_DTO";
    private Context context;
    private List<AmiciDTO> elenco;

    public RowAdapter(Context context, List<AmiciDTO> objects) {
        super(context, R.layout.activity_row, objects);
        this.context = context;
        this.elenco = objects;
    }


    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View rowView= inflater.inflate(R.layout.activity_row, null, true);

        final AmiciDTO currDto = elenco.get(position);

        Button rowBtn = rowView.findViewById(R.id.row_btn);
        rowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, DetailActivity.class);
                i.putExtra( PAR_AMICO_DTO, currDto );
                context.startActivity( i );
            }
        });

        TextView txtTitle = rowView.findViewById(R.id.row_label);
        txtTitle.setText(currDto.getCognome());

        ImageView rowBall = rowView.findViewById(R.id.row_icon);
        if( currDto.getSeOnline()==1 )
            rowBall.setImageResource(R.mipmap.ball_green);
        else
            rowBall.setImageResource(R.mipmap.ball_red);

        return rowView;
    }
}
